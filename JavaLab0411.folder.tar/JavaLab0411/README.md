# Java Training @chtti 302
## last modified: 2019-Apr-11

### Main5

* object creation

### Main30

* concat BufferedReader with FileReader/BufferedWriter with File Writer


```
BufferedReader bufferedReader =
                new BufferedReader(new FileReader("data\\README_TXT"));
```

### Main31
* output stream (w/buffer)

### Main32
* lexical