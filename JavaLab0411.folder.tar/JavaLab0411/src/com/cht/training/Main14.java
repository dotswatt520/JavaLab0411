package com.cht.training;

enum OSType {
    IOS(10), Android(20), Linux(30), ChromeOS(40), 倚天(50);
    private int id;

    private OSType(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}

class OSDetail {
    private OSType type;

    public OSDetail(OSType type) {
        this.type = type;
    }

    public void vendor() {
        switch (type) {
            case IOS:
                System.out.println("APPLE:" + type.getId());
                break;
            case Linux:
                System.out.println("RedHat:" + type.getId());
                break;
            case Android:
                System.out.println("Google:" + type.getId());
                break;
            case ChromeOS:
                System.out.println("Alphabet:" + type.getId());
                break;
            case 倚天:
                System.out.println("倚天:" + type.getId());
                break;

        }
    }
}

public class Main14 {
    public static void main(String[] args) {
        OSDetail detail1 = new OSDetail(OSType.倚天);
        detail1.vendor();
    }
}
