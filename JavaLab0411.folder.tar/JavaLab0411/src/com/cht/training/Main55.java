package com.cht.training;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class Main55 {
    public static void main(String[] args) {
        String string1 = "abcde12345";
        StringBuilder builder = new StringBuilder();
        List<Character> list1 = new LinkedList<>();
        for (char stringChar: string1.toCharArray()) {
            list1.add(stringChar);
        }
        ListIterator<Character> reverseIterator = list1.listIterator(list1.size());
        while(reverseIterator.hasPrevious()) {
            char c = reverseIterator.previous();
            builder.append(c);
        }
        System.out.println("reverse string="+builder.toString());
    }
}
