package com.cht.training.Lab13;

public class Employee {
    static {
        counter = 200;
    }
    //private static int counter=100;
    private static int counter;
    public Employee() {
        counter++;
    }

    public static int getCount() {
        return counter;
    }

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            Employee e1 = new Employee();
            System.out.println(Employee.getCount());
        }
    }
}
