package com.cht.training;

class Asset {
    private String name;
    private int twd;
    private int usd;
    private static final int RATE = 31;
}


public class Main63 {
    public static void main(String[] args) {

    }
}
