package com.cht.training.Lab8d;

import com.cht.training.Lab8.Employee;

public class Contractor extends Employee {
    public void doSomething() {
        System.out.println("a=" + a);
        System.out.println("b=" + b);
        //System.out.println("c=" + c);
        //System.out.println("d=" + d);
    }
}
