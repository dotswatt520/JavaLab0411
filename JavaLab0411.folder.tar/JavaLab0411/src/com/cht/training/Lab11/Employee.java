package com.cht.training.Lab11;

public abstract class Employee {
    public int getSalary() {
        return 0;
    }

    abstract void working();


}
