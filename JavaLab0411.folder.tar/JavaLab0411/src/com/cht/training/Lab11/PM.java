package com.cht.training.Lab11;

public class PM extends Employee {
    @Override
    void working() {
        System.out.println("do some PM job");
    }
}
