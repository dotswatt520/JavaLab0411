package com.cht.training.Lab12;

public  class Employee {
    final int gradeLevel;

    public Employee() {
        gradeLevel = 0;
    }
    public Employee(int grade){
        gradeLevel = grade;
    }

    public final int getGradeLevel() {
        return gradeLevel;
    }

    public  void onBoard() {
        System.out.println("Hi I am a newbee");
    }
}
