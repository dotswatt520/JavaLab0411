package com.chtti.training;

public class GradleLab1 {
    public static void main(String[] args) {
        System.out.println("Hello Gradle @@chtti302");
    }
}
