package com.chtti.training;

public class GradleLab2 {
    public static void main(String[] args) {
        System.out.println("hihi, gradle finally works");
    }
}
