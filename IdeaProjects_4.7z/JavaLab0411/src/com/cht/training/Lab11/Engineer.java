package com.cht.training.Lab11;

public class Engineer extends Employee {
    @Override
    void working() {
        System.out.println("do some R&D job");
    }
    void debug() {
        System.out.println("@#*&$(*#@&$(*#&$(*#");
    }
}
