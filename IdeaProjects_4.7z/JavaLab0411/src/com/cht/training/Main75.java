package com.cht.training;

public class Main75 {
    public static void main(String[] args) {

        if (args.length >= 1) {

            String string1 = new String(args[0]);
        } else {
            System.out.println("please pass a parameter");

        }


    }
}
