package com.cht.training;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main72 {
    public static void main(String[] args) {
        String string1 = "1358";
        //String string1 = "";
        //String string1 = "abcd";
        try (Scanner scanner = new Scanner(string1)) {

            System.out.println("your input is:" + scanner.nextInt());
        } catch (InputMismatchException ime) {
            System.out.println("format is wrong, stack trace is:");
            //ime.printStackTrace();
        } catch (NoSuchElementException | IllegalStateException exception) {
            System.out.println("anyway input error");
        }


    }
}
