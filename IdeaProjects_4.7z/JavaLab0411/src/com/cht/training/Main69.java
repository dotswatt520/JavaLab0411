package com.cht.training;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main69 {
    public static void main(String[] args) {
        //String string1 = "1358";
        String string1 = "";
        //String string1 = "abcd";
        Scanner scanner = new Scanner(string1);
        scanner.close();
        try {

            System.out.println("your input is:" + scanner.nextInt());
        } catch (InputMismatchException ime) {
            System.out.println("format is wrong, stack trace is:");
            //ime.printStackTrace();
        } catch (NoSuchElementException | IllegalStateException exception) {
            System.out.println("anyway input error");
        }
//        catch (NoSuchElementException nsee) {
//            System.out.println("input is not enough");
//        } catch (IllegalStateException ise) {
//            System.out.println("illegal state");
//        }
        scanner.close();
        System.out.println("close scanner");
    }
}
