package com.cht.training;
public interface XYZ1 {
}
