package com.cht.training;

import java.util.*;

public class Main58 {
    public static void main(String[] args) {
        Map<String, String> phoneBook = new HashMap<>();
        phoneBook.put("Mark", "111-1111");
        phoneBook.put("Ken", "222-2222");
        phoneBook.put("Tim", "333-3333");
        Set<String> keySet = phoneBook.keySet();
        List<String> sortedKey = new ArrayList(keySet);
        Collections.sort(sortedKey);
        for (String key : sortedKey) {
            System.out.printf("key=%s, value=%s\n", key, phoneBook.get(key));
        }
    }
}
