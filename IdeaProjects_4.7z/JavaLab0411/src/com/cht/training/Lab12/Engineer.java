package com.cht.training.Lab12;

public class Engineer extends Employee {
    @Override
    public void onBoard() {
        super.onBoard();
    }
}
