package com.cht.training;

public class Main1 {
private static final String TAG1= "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
    public static void main(String[] args) {
        System.out.println("I1lO0");
    }
}

class Foo {

}
