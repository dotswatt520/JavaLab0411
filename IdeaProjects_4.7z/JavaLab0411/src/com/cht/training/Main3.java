package com.cht.training;

public class Main3 {
    public static void main(String[] args) {
        int x = 0b010101;
        System.out.println("x=" + x);
        long y = 1_000_000_001;
        long z = 10_0000_0001;
        System.out.println("y-z=" + (y - z));
    }
}
