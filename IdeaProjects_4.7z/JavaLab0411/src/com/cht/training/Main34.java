package com.cht.training;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Main34 {
    public static void main(String[] args) throws IOException {
        try (FileInputStream inputStream = new FileInputStream("data\\Main1.7z")) {
            byte[] buffer = new byte[6];
            if (inputStream.read(buffer) != -1) {
                System.out.printf("buffer=[%s],[%s],[%s],[%s],[%s],[%s]\n",
                        Integer.toHexString(buffer[0]).toUpperCase(),
                        Integer.toHexString(buffer[1]).toUpperCase(),
                        Integer.toHexString(buffer[2]).toUpperCase(),
                        Integer.toHexString(buffer[3]).toUpperCase(),
                        Integer.toHexString(buffer[4]).toUpperCase(),
                        Integer.toHexString(buffer[5]).toUpperCase());
            }

        }
        System.out.println("7z magic number:");
        System.out.print((char)55);
        System.out.print((char)122);


    }
}
