package com.cht.training.Lab8;

public interface Working {
    public void startWork();
    public void endWork();
}
