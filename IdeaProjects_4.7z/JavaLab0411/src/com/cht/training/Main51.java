package com.cht.training;

import java.util.ArrayList;
import java.util.List;

public class Main51 {
    public static void main(String[] args) {
        List<Number> list1 = new ArrayList<Number>();
        list1.add(123);
        list1.add(45.67);
        List<String> list2 = new ArrayList<String>();
        list2.add("123");
        list2.add("45.67");
        displayList(list1);
        displayList(list2);
    }

    private static void displayList(List<?> list) {
        for (Object item : list) {
            System.out.printf("<<%s>>", item.toString());
        }
        System.out.println();
    }
}
